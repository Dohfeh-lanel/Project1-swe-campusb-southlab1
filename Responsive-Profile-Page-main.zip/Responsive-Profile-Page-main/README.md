<div align="center">
<img src="https://github.com/MohammadSahragard/Responsive-Profile-Page/blob/main/Thumbnile.png?raw=true" align="center" style="width: 100%" alt="responsive profile page" />
</div>  
  
# Responsive Profile Page  
<br/>
Well, this is the first project that I recorded for YouTube and shared the source code on GitHub.
This is a simple profile page. And I designed the user interface (UI) myself, Ok, not good 😂🤦🏻 Sorry, but it was my first design.
I like your comments ❤️🙏.


<br/>

### For Support Me, See:
  1. [YouTube](https://t.co/aMYyLNZsdZ)
  2. [Instagram]()
  3. [Linkedin](https://www.linkedin.com/posts/mohammadsahragard_responsive-profile-page-with-html-and-css-activity-6972551215297482752-n_Iw?utm_source=share&utm_medium=member_android)
  4. [Twitter](https://twitter.com/MammadSahragard/status/1566787380379586560?t=WtmjmvziGmi44HpU6YXCZQ&s=19)
  5. [Dev](https://dev.to/mohammadsahragard/responsive-profile-page-561i)

<br/>  

### Technologies Used  
<div align="left">  
<a href="https://www.w3schools.com/css/" target="_blank"><img style="margin: 10px" src="https://profilinator.rishav.dev/skills-assets/css3-original-wordmark.svg" alt="CSS3" height="50" /></a>  
<a href="https://en.wikipedia.org/wiki/HTML5" target="_blank"><img style="margin: 10px" src="https://profilinator.rishav.dev/skills-assets/html5-original-wordmark.svg" alt="HTML5" height="50" /></a>  
</div>  

<br/>

## For More Tutorials:
###### (I mean follow and sub me. Because I don't have a video yet, this was my first video 😂.)
<a href="https://twitter.com/MammadSahragard" target="_blank">
<img src=https://img.shields.io/badge/twitter-%2300acee.svg?&style=for-the-badge&logo=twitter&logoColor=white alt=twitter style="margin-bottom: 5px;" />
</a>
<a href="https://dev.to/MohammadSahragard" target="_blank">
<img src=https://img.shields.io/badge/dev.to-%2308090A.svg?&style=for-the-badge&logo=dev.to&logoColor=white alt=devto style="margin-bottom: 5px;" />
</a>
<a href="https://linkedin.com/in/MohammadSahragard" target="_blank">
<img src=https://img.shields.io/badge/linkedin-%231E77B5.svg?&style=for-the-badge&logo=linkedin&logoColor=white alt=linkedin style="margin-bottom: 5px;" />
</a>
<a href="https://instagram.com/Mammad.Sahragard" target="_blank">
<img src=https://img.shields.io/badge/instagram-%23000000.svg?&style=for-the-badge&logo=instagram&logoColor=white alt=instagram style="margin-bottom: 5px;" />
</a>
<a href="https://github.com/MohammadSahragard" target="_blank">
<img src=https://img.shields.io/badge/github-%2324292e.svg?&style=for-the-badge&logo=github&logoColor=white alt=github style="margin-bottom: 5px;" />
</a>
<a href="https://www.youtube.com/user/https://www.youtube.com/channel/UCmlrWX41qiXEv6QNMzivxIw" target="_blank">
<img src=https://img.shields.io/badge/youtube-%23EE4831.svg?&style=for-the-badge&logo=youtube&logoColor=white alt=youtube style="margin-bottom: 5px;" />
</a>  
</div>  
